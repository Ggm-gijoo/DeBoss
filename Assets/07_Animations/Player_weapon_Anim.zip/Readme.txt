Thank you for your purchase.

The animation was created Root Motion.
If you want inplace motion, uncheck the Apply Root Motion box in the Animator component.

If you want the animation to work more perfectly, please reduce the rotation and position errors in the Animation tab.

The sample controller is just for viewing the animation.

Hand positions for each weapon.
01 Sword&Shield - Sword:Hand_R, Shield:Forearm_L
02 Hammer - Hand_R
03 DualBlades - Hand_R,Hand_L
04 Bow - Hand_L
05 Pistol - Hand_R
07 Spear - Hand_L
08 Staff - Hand_L
10 Rapier - Hand_L
11DoubleBlade - Hand_R
12 Claymore - Hand_R

If you have any questions, please email us at sts073311@gmail.com.